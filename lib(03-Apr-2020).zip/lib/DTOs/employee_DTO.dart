class EmployeeData {
  String status;
  List<Employee> employees;

  EmployeeData(this.status, [this.employees]);

  factory EmployeeData.fromJson(dynamic json) {
    var tagObjsJson = json['data'] as List;
    List<Employee> _employees = tagObjsJson
        .map((employeeJson) => Employee.fromJson(employeeJson))
        .toList();

    return EmployeeData(json['status'] as String, _employees);
  }
}

class Employee {
  String id;
  String employeeName;
  String employeeSalary;
  String employeeAge;
  String profileImage;

  Employee(this.id, this.employeeName, this.employeeSalary, this.employeeAge,
      this.profileImage);

  factory Employee.fromJson(dynamic json) {
    return Employee(
      json['id'] as String,
      json['employee_name'] as String,
      json['employee_salary'] as String,
      json['employee_age'] as String,
      json['profile_image'] as String,
    );
  }
}
