import 'dart:convert';
import 'dart:ffi';

import 'package:employee_app/DTOs/employee_DTO.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class AddEmployee extends StatelessWidget {
  final empNameController = TextEditingController();
  final empSalaryController = TextEditingController();
  final empAgeController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: AppBar(
        title: Text('Add Employee'),
      ),
      body: addForm(),
    );
  }

  Padding addForm() {
    return Padding(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          getTextField(empNameController,'Employee Name'),
          getTextField(empSalaryController,'Employee Salary'),
          getTextField(empAgeController,'Employee Age'),
          Center(
            child: FlatButton(
              color: Colors.red,
              textColor: Colors.white,
              child: Text('Create'),
              onPressed: () {
                var response = createEmployee();
                print(response.toString());
              },
            ),
          )
        ],
      ),
      padding: EdgeInsets.fromLTRB(15, 10, 15, 10),
    );
  }

  Padding getTextField(TextEditingController controller, String label) => Padding(
      padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(label),
          TextField(
            controller: controller,
          ),
        ],
      ));

  Future<http.Response> createEmployee() async {
    var response = await http.post(
      'http://dummy.restapiexample.com/api/v1/create',
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: json.encode(
        {
          'name': 'Abdul 1',
          'salary': '100000',
          'age': '28',
        },
      ),
    );
    print("${response.statusCode}");
    print("${response.body}");
    return response;
  }
}
