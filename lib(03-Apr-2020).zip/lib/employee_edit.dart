import 'DTOs/employee_DTO.dart';
import 'package:flutter/material.dart';

class EditEmployee extends StatelessWidget {
  final Employee employee;
  EditEmployee({Key key, this.employee}) : super(key: key);
  final empNameController = TextEditingController();
  final empSalaryController = TextEditingController();
  final empAgeController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(employee.employeeName),
      ),
      body: editView(),
    );
  }

  Padding editView() {
    empNameController.text = employee.employeeName;
    empSalaryController.text = employee.employeeSalary;
    empAgeController.text = employee.employeeAge;
    return Padding(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          getTextField(empNameController,'Employee Name'),
          getTextField(empSalaryController,'Employee Salary'),
          getTextField(empAgeController, 'Employee Age'),
          Center(
            child: FlatButton(
              color: Colors.red,
              textColor: Colors.white,
              child: Text('Update'),
              onPressed: () {},
            ),
          )
        ],
      ),
      padding: EdgeInsets.fromLTRB(15, 10, 15, 10),
    );
  }

  Padding getTextField(TextEditingController controller, String label) => Padding(
        padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
       child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(label),
          TextField(
            controller: controller,
          ),
        ],
      )
      );

  final TextStyle textStyle = TextStyle(fontSize: 18);
}
